

    public class ItalianChef extends Chef {


        public void makePasta() {
            System.out.println("\nThe italian chef is making a pasta");
        }

}
