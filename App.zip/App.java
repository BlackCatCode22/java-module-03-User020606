

    public class App {
        public static void main(String[] args) {

        Chef myChef = new Chef();

        myChef.makeChicken();


        ItalianChef myItalianChef = new ItalianChef();

        myItalianChef.makeSalad();
        myItalianChef.makePasta();


        ChineseChef myChineseChef = new ChineseChef();

        myChineseChef.makeFriedRice();


    }
}
