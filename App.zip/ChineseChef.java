

    public class ChineseChef {

        public void makeFriedRice() {
            System.out.println("\nThe chinese chef is making fried rice");
        }


}
