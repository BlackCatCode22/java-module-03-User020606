

    public class Chef {

         public void makeChicken() {
           System.out.println("\nThe Chef makes a delicious chicken");
         }

         public void makeSalad() {
           System.out.println("\nThe Chef makes a healthy salad");
        }

         public void makeSpicalDish() {
           System.out.println("\nThe Chef makes a delicious ");
         }
}
