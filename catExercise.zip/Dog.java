public class Dog {
    String name;
    int age;

    public Dog(String name) {
        this.name = name;
    }
}
