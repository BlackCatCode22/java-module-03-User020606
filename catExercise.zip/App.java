

    public class App {
        public static void main(String[] args) {

            Cat myCat = new Cat();

            myCat.meow();
            myCat.name = "Vincent";
            myCat.age = 8;

            System.out.println("The cat's name is " + myCat.name);
            System.out.println("The cat's age is " + myCat.age);


            System.out.println("There is " + Cat.getCatCount() + " cat here");
    }
}
